# Hello-World
Repositorio 
Heloo! World
Confirma que ya has hecho lo siguiente:
Genera un par de claves de firma API.
Se agregó el valor de clave pública del par de claves de firma de API a la Configuración de usuario para su nombre de usuario.
Instaló y configuró la CLI de Oracle Cloud Infrastructure (versión 2.6.4 o posterior).
Si no ha hecho uno o más de los anteriores, o no está seguro, consulte el tema Configuración del acceso al clúster en la documentación del Motor de contenedores para Kubernetes.

Con la piscinas de nodo página que muestra detalles de pool1, haga clic en Tutorial Cluster en la ruta de navegación. Haga clic en Clúster de acceso para mostrar el cuadro de diálogo Acceda a su clúster y luego haga clic en Acceso local .
https://github.com/flsosa/Hello-World/issues/3#issue-624458120
![Filosofomodificado-1160x700](https://user-images.githubusercontent.com/54222755/82839618-566d8800-9ea6-11ea-8256-fd38a2f0c13f.jpg)
